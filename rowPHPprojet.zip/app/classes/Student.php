<?php

namespace App\classes;

class Student
{
    public $name;
    public $email;
    public $mobile;

    public function __construct()
    {
        $this->name = 'Yousuf Khan';
        $this->email = 'yousuf@gmail.com';
        $this->mobile = '01787649949';
    }

    public function getName()
    {
        echo $this->name;
    }
    public function getEmail()
    {
        echo $this->email;
    }
    public function getMobile()
    {
        echo $this->mobile;
    }


}